"""
Cymbal Retail Agents — Step 2: Create the Vertex AI RAG Engine corpus
=====================================================================
Creates a managed RAG corpus, uploads the three policy documents from
data/knowledge_base/, and prints the corpus resource name that you must
paste into your .env file as RAG_CORPUS.

Usage:
    export GOOGLE_CLOUD_PROJECT=your-project-id
    export GOOGLE_CLOUD_LOCATION=us-central1
    python setup/02_create_rag_corpus.py
"""

import os
import sys
import time
from pathlib import Path

import vertexai
from vertexai import rag

PROJECT_ID = os.environ.get("GOOGLE_CLOUD_PROJECT")
LOCATION = os.environ.get("GOOGLE_CLOUD_LOCATION", "us-central1")
CORPUS_DISPLAY_NAME = "cymbal-retail-policies"
KB_DIR = Path(__file__).resolve().parent.parent / "data" / "knowledge_base"


def main() -> None:
    if not PROJECT_ID:
        sys.exit("❌ Set GOOGLE_CLOUD_PROJECT first, e.g. export GOOGLE_CLOUD_PROJECT=my-proj")

    print(f"🔧 Initializing Vertex AI  |  project={PROJECT_ID}  location={LOCATION}")
    vertexai.init(project=PROJECT_ID, location=LOCATION)

    # ---- Reuse the corpus if it already exists (idempotent for classrooms) ----
    existing = [c for c in rag.list_corpora() if c.display_name == CORPUS_DISPLAY_NAME]
    if existing:
        corpus = existing[0]
        print(f"ℹ️  Corpus already exists, reusing: {corpus.name}")
    else:
        print(f"🔧 Creating RAG corpus '{CORPUS_DISPLAY_NAME}' "
              f"(managed vector DB + text-embedding-005)...")
        corpus = rag.create_corpus(
            display_name=CORPUS_DISPLAY_NAME,
            backend_config=rag.RagVectorDbConfig(
                rag_embedding_model_config=rag.RagEmbeddingModelConfig(
                    vertex_prediction_endpoint=rag.VertexPredictionEndpoint(
                        publisher_model="publishers/google/models/text-embedding-005"
                    )
                )
            ),
        )
        print(f"✅ Corpus created: {corpus.name}")

    # ---- Upload each knowledge base file directly (no GCS needed) ----
    files = sorted(KB_DIR.glob("*.md"))
    if not files:
        sys.exit(f"❌ No .md files found in {KB_DIR}")

    already = {f.display_name for f in rag.list_files(corpus.name)}
    for path in files:
        if path.name in already:
            print(f"ℹ️  Skipping (already imported): {path.name}")
            continue
        print(f"⬆️  Uploading {path.name} ...")
        rag.upload_file(
            corpus_name=corpus.name,
            path=str(path),
            display_name=path.name,
            description=f"Cymbal Retail policy document: {path.stem}",
        )
        time.sleep(2)  # be gentle on trial-account quotas

    print("\n📄 Files now in corpus:")
    for f in rag.list_files(corpus.name):
        print(f"   - {f.display_name}")

    print("\n" + "=" * 70)
    print("✅ RAG corpus ready. Add this line to your .env file:")
    print(f"\nRAG_CORPUS={corpus.name}\n")
    print("=" * 70)


if __name__ == "__main__":
    main()
