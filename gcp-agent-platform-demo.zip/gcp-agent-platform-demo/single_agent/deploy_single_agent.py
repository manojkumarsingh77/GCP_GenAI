"""
Deploys the customer_support_agent to Vertex AI Agent Engine
(the managed runtime on GCP Agent Platform).

Run this AFTER you have tested the agent locally with:
    adk run customer_support_agent
    adk web

Usage:
    python deploy_single_agent.py \
        --project=YOUR_PROJECT_ID \
        --location=us-central1 \
        --bucket=gs://YOUR_STAGING_BUCKET

NOTE: As of mid-2026 you can also do this with a single CLI command instead
of this script:
    adk deploy agent_engine \
        --project=YOUR_PROJECT_ID \
        --region=us-central1 \
        --staging_bucket=gs://YOUR_STAGING_BUCKET \
        customer_support_agent
Both approaches end up in the same place (an Agent Engine resource).
This script is useful when you want deployment to be part of a CI/CD pipeline.
"""

import argparse
import vertexai
from vertexai.preview import reasoning_engines
from vertexai import agent_engines

from customer_support_agent.agent import root_agent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True)
    parser.add_argument("--location", default="us-central1")
    parser.add_argument("--bucket", required=True, help="gs://your-staging-bucket")
    args = parser.parse_args()

    vertexai.init(
        project=args.project,
        location=args.location,
        staging_bucket=args.bucket,
    )

    # Wrap the ADK agent so Agent Engine knows how to serve it
    app = reasoning_engines.AdkApp(
        agent=root_agent,
        enable_tracing=True,
    )

    print("Deploying customer_support_agent to Agent Engine... this can take 5-10 min")

    remote_agent = agent_engines.create(
        app,
        requirements=[
            "google-adk",
            "google-cloud-aiplatform[adk,agent_engines]",
        ],
        display_name="customer-support-agent",
    )

    print("\nDeployment complete!")
    print("Resource name:", remote_agent.resource_name)
    print("Use this resource name in the Vertex AI Console > Agent Engine")
    print("or call it via the Agent Engine query API.")


if __name__ == "__main__":
    main()
